# Gradient Descent Implementation

## Setup
* Set up conda environment using the exported `environment.yml`
  * Or: use an environment with `numpy`, `scipy`, and `behave` installed

## Testing
* `behave` for test suite
* `behave --no-capture` for test suite with visible logging
